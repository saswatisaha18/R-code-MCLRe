#line 566 "chebsample.nw"
make_g1 <- function(mu0, mu1)
    Vectorize(vectorize.args = "gamma",
              function(o, gamma) {
                  S <- cov(cbind(mu0(o, gamma), mu1(o, gamma)))
                  sqrt(det(S) / S[1, 1]^2)
              })
#line 590 "chebsample.nw"
g_emax <- make_g1(mu0 = function(o, gamma) o$x / (o$x + gamma),
                  mu1 = function(o, gamma) -(o$x / (o$x + gamma)^2))
#line 610 "chebsample.nw"
g_quadratic <- make_g1(mu0 = function(o, gamma) o$x + gamma * o$x^2,
                       mu1 = function(o, gamma) o$x^2)
#line 625 "chebsample.nw"
g_exponential <- make_g1(mu0 = function(o, gamma)
                             exp(o$x / gamma),
                         mu1 = function(o, gamma)
                             -o$x * exp(o$x / gamma) / gamma^2)
#line 650 "chebsample.nw"
make_g2 <- function(mu0, mu1, mu2)
    Vectorize(vectorize.args = c("gamma_1", "gamma_2"),
              function(o, gamma_1, gamma_2) {
                  S <- cov(cbind(mu0(o, gamma_1, gamma_2),
                                 mu1(o, gamma_1, gamma_2),
                                 mu2(o, gamma_1, gamma_2)))
                  dS <- det(S)
                  if (dS < 0) {
                      dS <- 0
                      warning("Matrix S negative definite.")
                  }
                  sqrt(dS / S[1, 1]^3)
              })
#line 681 "chebsample.nw"
g_sigEmax <- make_g2(function(o, gamma_1, gamma_2) {
                         num <- o$x^gamma_2 # numerator
                         den <- o$x^gamma_2 + gamma_1^gamma_2 # denominator
                         num / den
                     },
                     function(o, gamma_1, gamma_2) {
                         num <- -(gamma_2 / gamma_1) * (o$x * gamma_1)^gamma_2
                         den <- (o$x^gamma_2 + gamma_1^gamma_2)^2
                         num / den
                     },
                     function(o, gamma_1, gamma_2) {
                         num <- (gamma_1 * o$x)^gamma_2 * log(o$x / gamma_1)
                         den <- (o$x^gamma_2 + gamma_1^gamma_2)^2
                         num / den
                     })
#line 760 "chebsample.nw"
betaMod_mu0 <- function(o, gamma_1, gamma_2)
{
    x_1 <- o$x / o$sigma
    x_2 <- 1 - x_1
    B <- (gamma_1 + gamma_2)^{gamma_1 + gamma_2} / (gamma_1^gamma_1 + gamma_2^gamma_2)
    x_1^gamma_1 * x_2^gamma_2 * B
}

g_betaMod <- make_g2(betaMod_mu0,
                     function(o, gamma_1, gamma_2) {
                         mu0 <- betaMod_mu0(o, gamma_1, gamma_2)
                         x_1 <- o$x / o$sigma
                         log((1 + gamma_2 / gamma_1) * x_1) * mu0
                     },
                     function(o, gamma_1, gamma_2) {
                         mu0 <- betaMod_mu0(o, gamma_1, gamma_2)
                         x_2 <- 1 - o$x / o$sigma
                         log((1 + gamma_1 / gamma_2) * x_2) * mu0
                     })
#line 845 "chebsample.nw"
map_gamma <- function(o, gamma, p = 1)
    (2 * gamma - o$upsilon[p] - o$lambda[p]) / (o$upsilon[p] - o$lambda[p])
#line 850 "chebsample.nw"
map_eta <- function(o, eta, p = 1)
    ((o$upsilon[p] - o$lambda[p]) * eta + o$upsilon[p] + o$lambda[p]) / 2
#line 874 "chebsample.nw"
cheb_roots <- function(m)
    cos(pi * (1:m - 0.5) / m)
#line 943 "chebsample.nw"
cheb_coef <- function(v)
{
    m <- length(v)
    if (m == 1)
        2 * v
    else
        DCT(v, type = 2) / m
}
#line 980 "chebsample.nw"
cheb_trunc <- function(a, eps = 1e-5)
    a[1:max(which(abs(a) / max(abs(a)) > eps))]
#line 1023 "chebsample.nw"
cheb_val <- function(a, eta)
{
    m <- length(a)
    b1 <- b2 <- b3 <- 0
    for (k in seqm(m, 2)) {
        b3 <- b1
        b1 <- 2 * eta * b1 - b2 + a[k]
        b2 <- b3
    }
    a[1] / 2 + eta * b1 - b2
}
#line 1048 "chebsample.nw"
seqp <- function(from, to)
    if (from <= to)
        from:to
#line 1059 "chebsample.nw"
seqm <- function(from, to)
    if (from >= to)
        from:to
#line 1096 "chebsample.nw"
cheb_int <- function(a)
{
    m <- length(a)
    b <- vector("numeric", m + 1)
    for (k in seqp(2, m - 1)) {
        b[k] <- (a[k - 1] - a[k + 1]) / (2 * (k - 1))
        b[1] <- b[1] + 2 * (-1)^k * b[k]
    }
    for (k in max(2, m):(m + 1)) {
        b[k] <- a[k - 1] / (2 * (k - 1))
        b[1] <- b[1] + 2 * (-1)^k * b[k]
    }
    b
}
#line 1152 "chebsample.nw"
cheb_area <- function(a)
{
    m <- length(a)
    K <- 0:((m - 1) / 2)
    w <- -1 / ((2 * K + 1) * (2 * K - 1))
    w[1] <- w[1] / 2
    2 * drop(w %*% a[2 * K + 1])
}
#line 1175 "chebsample.nw"
cheb_cdf <- function(a)
    cheb_int(a) / cheb_area(a)
#line 1199 "chebsample.nw"
cheb_approx <- function(o, g, eps, underline_iota = 2, overline_iota = 5)
{
    iota <- underline_iota - 1
    while (iota < overline_iota && 
#line 1290 "chebsample.nw"
(iota < underline_iota || abs(a)[length(a)] / max(abs(a)) > eps)
#line 1202 "chebsample.nw"
                                                                         ) {
        iota <- iota + 1
        
#line 1227 "chebsample.nw"
    m <- 3^iota
    r <- cheb_roots(m)
#line 1259 "chebsample.nw"
    L <- iota > underline_iota & 1:m %% 3 == 2
    w <- if(iota > underline_iota) v # equals NULL during first step
    v <- rep(0, m)
    v[L] <- w
    v[!L] <- g(o, map_eta(o, r[!L]))
#line 1271 "chebsample.nw"
    a <- cheb_coef(v)
#line 1205 "chebsample.nw"
    }
    a
}
#line 1335 "chebsample.nw"
cheb_bisect <- function(a, alpha, eps)
{
    beta <- rep(-1, length(alpha))
    for (delta in 2^(0:(1 + floor(log2(eps)))))
        beta <- beta + (cheb_val(a, beta + delta) < alpha) * delta
    beta + delta / 2 # return the midpoint of the final bracket
}
#line 1365 "chebsample.nw"
cheb_q <- function(o, g, eps_1, eps_2, eps_3, eps_4, eps_5)
{
    a <- cheb_trunc(cheb_cdf(cheb_approx(o, g, eps = eps_1)), eps_2)
    q <- function(o, alpha) cheb_bisect(a, alpha, eps_3)
    cheb_trunc(cheb_approx(list(lambda = 0, upsilon = 1), q, eps = eps_4), eps_5)
}
#line 1380 "chebsample.nw"
map_alpha <- function(alpha)
    2 * alpha - 1
#line 1395 "chebsample.nw"
rsample <- function(o, a, n)
    map_eta(o, cheb_val(a, map_alpha(runif(n))))
#line 1406 "chebsample.nw"
esample <- function(o, a, n)
    map_eta(o, cheb_val(a, map_alpha(seq(0, 1, length.out = n))))
#line 1412 "chebsample.nw"
qsample <- function(o, a, n)
    map_eta(o, cheb_val(a, map_alpha(sobol(n))))
#line 1544 "chebsample.nw"
cheb_coef_mat <- function(V)
    apply(V, 2, cheb_coef)
#line 1557 "chebsample.nw"
cheb_trunc_mat <- function(A, eps)
{
    underline_m <- max(row(A)[abs(A) > eps * max(abs(A))])
    A[1:underline_m, , drop = FALSE]
}
#line 1575 "chebsample.nw"
cheb_val_mat <- function(A, eta)
{
    m <- nrow(A)
    Ones <- matrix(1, length(eta))
    B1 <- B2 <- B3 <- matrix(0, length(eta), ncol(A))
    for (k in seqm(m, 2)) {
        B3 <- B1
        B1 <- 2 * eta * B1 - B2 + Ones %*%  A[k, , drop = FALSE]
        B2 <- B3
    }
    eta * B1 - B2 + 0.5 * Ones %*% A[1, ]
}
#line 1599 "chebsample.nw"
cheb_int_mat <- function(A)
{
    m <- nrow(A)
    B <- matrix(0, m + 1, ncol(A))
    for (k in seqp(2, m - 1)) {
        B[k, ] <- (A[k - 1, ] - A[k + 1, ]) / (2 * (k - 1))
        B[1, ] <- B[1, ] + 2 * (-1)^k * B[k, ]
    }
    for (k in max(2, m):(m + 1)) {
        B[k, ] <- A[k - 1, ] / (2 * (k - 1))
        B[1, ] <- B[1, ] + 2 * (-1)^k * B[k, ]
    }
    B
}
#line 1624 "chebsample.nw"
cheb_area_mat <- function(A)
{
    m <- nrow(A)
    K <- 0:((m - 1) / 2)
    w <- -1 / ((2 * K + 1) * (2 * K - 1))
    w[1] <- w[1] / 2
    2 * w %*% A[2 * K + 1, , drop = FALSE]
}
#line 1654 "chebsample.nw"
ACA <- function(V, n, eps)
{
    m <- nrow(V)
    j <- 0
    
#line 1713 "chebsample.nw"
    R <- matrix(0, n, m)
    C <- matrix(0, m, n)
    u <- vector("numeric", n)
    Pi <- matrix(0, 2, n)
#line 1733 "chebsample.nw"
    Delta <- t(V)
#line 1659 "chebsample.nw"
    while (j < n && 
#line 1802 "chebsample.nw"
    max(abs(Delta)) / max(abs(V)) > eps
#line 1659 "chebsample.nw"
                                                                      ) {
        j <- j + 1
        
#line 1742 "chebsample.nw"
    Pi[, j] <- argmax(Delta)
#line 1765 "chebsample.nw"
    R[j, ] <- Delta[Pi[1, j], ]
    C[, j] <- Delta[, Pi[2, j]]
    u[j] <- Delta[Pi[1, j], Pi[2, j]]
    Delta <- Delta - C[, j, drop = FALSE] %*% R[j, , drop = FALSE] / u[j]
#line 1662 "chebsample.nw"
    }
    list(
#line 1721 "chebsample.nw"
    R = R[1:j, , drop = FALSE],
    C = C[, 1:j, drop = FALSE],
    u = u[1:j],
    Pi = Pi[, 1:j, drop = FALSE],
#line 1809 "chebsample.nw"
    fail = 
#line 1802 "chebsample.nw"
    max(abs(Delta)) / max(abs(V)) > eps
#line 1663 "chebsample.nw"
                                        )
}
#line 1750 "chebsample.nw"
argmax <- function(Delta)
{
    n <- nrow(Delta)
    i <- which.max(abs(Delta))
    row_index <- ((i - 1) %% n) + 1
    col_index <- floor((i - 1) / n) + 1
    c(row_index, col_index)
}
#line 1836 "chebsample.nw"
PartialACA <- function(Pi, R, C, u)
{
    n <- nrow(R)
    for (j in seqp(1, n - 1)) {
        # update columns
        C_j <- C[, j, drop = FALSE]
        R_j_pi <- R[j, Pi[2, (j + 1):n], drop = FALSE]
        C[, (j + 1):n] <- C[, (j + 1):n] - C_j %*% R_j_pi / u[j];
        # update rows
        C_pi_j <- C[Pi[1, (j + 1):n], j, drop = FALSE]
        R_j <- R[j, , drop = FALSE]
        R[(j + 1):n, ] <-  R[(j + 1):n, ] -  C_pi_j %*% R_j / u[j]
    }
    list(R = R, C = C)
}
#line 1891 "chebsample.nw"
lr_approx <- function(o, g, eps_1, eps_2, underline_iota = 2, overline_iota= 5)
{
    
#line 1920 "chebsample.nw"
    D <- list(fail = TRUE)
    iota <- underline_iota - 1
    while (D$fail && iota < overline_iota) {
        iota <- iota + 1
        m <- 3^iota
        n <- 3^(iota - 1)
        
#line 1945 "chebsample.nw"
    r <- cheb_roots(m)
    Xi <- expand.grid(r, r)
    L <- iota > underline_iota & 1:m %% 3 == 2
    J <- as.vector(outer(L, L, "&"))
    w <- if(iota > underline_iota) v
    v <- vector("numeric", m^2)
    v[J] <- w
    v[!J] <- g(o, map_eta(o, Xi[!J, 1], 1), map_eta(o, Xi[!J, 2], 2))
    V <- matrix(v, m)
#line 1927 "chebsample.nw"
        D <- ACA(V, n, eps_1)
    }
#line 1894 "chebsample.nw"
    
#line 1967 "chebsample.nw"
    
#line 1985 "chebsample.nw"
    Pi <- D$Pi
    u <- D$u
#line 1991 "chebsample.nw"
    gamma_1 <- map_eta(o, r[Pi[1, ]], 1)
    gamma_2 <- map_eta(o, r[Pi[2, ]], 2)
#line 2002 "chebsample.nw"
    iota_1 <- iota_2 <- iota
    m_1 <- m_2 <- m
#line 2009 "chebsample.nw"
    V_1 <- V[Pi[1, ], , drop = FALSE]
    V_2 <- V[, Pi[2, ], drop = FALSE]
#line 1968 "chebsample.nw"
    
#line 2018 "chebsample.nw"
A_1 <- cheb_trunc_mat(cheb_coef_mat(t(D$R)), eps_2)
A_2 <- cheb_trunc_mat(cheb_coef_mat(D$C), eps_2)
#line 1969 "chebsample.nw"
    while (
#line 2029 "chebsample.nw"
(iota_1 <= overline_iota && nrow(A_1) == m_1)
#line 1969 "chebsample.nw"
                                       ||  
#line 2032 "chebsample.nw"
(iota_2 <= overline_iota && nrow(A_2) == m_2)
#line 1969 "chebsample.nw"
                                                                      ) {
        if (
#line 2029 "chebsample.nw"
(iota_1 <= overline_iota && nrow(A_1) == m_1)
#line 1970 "chebsample.nw"
                                       ) {
            
#line 2054 "chebsample.nw"
    iota_1 <- iota_1 + 1
    m_1 <- 3^iota_1
    r <- cheb_roots(m_1)
    L <- 1:m_1 %% 3 == 2
    V_1 <- t(matrix(rep(t(V_1), each = 3), m_1))
    V_1[, !L] <- outer(gamma_1, map_eta(o, r[!L], 2), g, o = o)
#line 2064 "chebsample.nw"
    Pi[2, ] <- Pi[2, ] * 3 - 1
#line 1972 "chebsample.nw"
        }
        if (
#line 2032 "chebsample.nw"
(iota_2 <= overline_iota && nrow(A_2) == m_2)
#line 1973 "chebsample.nw"
                                       ) {
            
#line 2068 "chebsample.nw"
    iota_2 <- iota_2 + 1
    m_2 <- 3^iota_1
    r <- cheb_roots(m_2)
    L <- 1:m_2 %% 3 == 2
    V_2 <- matrix(rep(V_2, each=3), m_2)
    V_2[!L, ] <- outer(map_eta(o, r[!L], 1), gamma_2, g, o = o)
    Pi[1, ] <- Pi[1, ] * 3 - 1
#line 1975 "chebsample.nw"
        }
        
#line 2039 "chebsample.nw"
    D <- PartialACA(Pi, V_1, V_2, u)
    
#line 2018 "chebsample.nw"
A_1 <- cheb_trunc_mat(cheb_coef_mat(t(D$R)), eps_2)
A_2 <- cheb_trunc_mat(cheb_coef_mat(D$C), eps_2)
#line 1977 "chebsample.nw"
    }
#line 1895 "chebsample.nw"
    list(A_1 = A_1, A_2 = A_2, u = u)
}
#line 2101 "chebsample.nw"
bivariate_density <- function(Psi)
    list(A_1 = Psi$A_1,
         A_2 = Psi$A_2,
         u = lr_area(Psi) * Psi$u)
#line 2119 "chebsample.nw"
lr_area <- function(Psi)
    drop(cheb_area_mat(Psi$A_1)  %*% t(cheb_area_mat(Psi$A_2) / Psi$u))
#line 2146 "chebsample.nw"
marginal_density <- function(Psi)
    drop(Psi$A_1 %*% t(cheb_area_mat(Psi$A_2) / Psi$u))
#line 2192 "chebsample.nw"
conditional_density <- function(Psi, b, eta_1)
{
    V <- diag(1 / cheb_val(b, eta_1), length(eta_1))
    H <- cheb_val_mat(Psi$A_1, eta_1)
    U <- diag(1 / Psi$u, length(Psi$u))
    W <- V %*% H %*% U
    Psi$A_2 %*% t(W)
}
#line 2225 "chebsample.nw"
lr_val <- function(Psi, eta_1, eta_2)
{
    H_1 <- cheb_val_mat(Psi$A_1, eta_1)
    H_2 <- cheb_val_mat(Psi$A_2, eta_2)
    U <- diag(1 / Psi$u, length(Psi$u))
    diag(H_1 %*% U %*% t(H_2))
}
#line 2252 "chebsample.nw"
lr_q <- function(o, g, eps_1, eps_2, eps_3, eps_4, eps_5, eps_6, iota = 4)
{
    Psi <- bivariate_density(lr_approx(o, g, eps_1 = eps_1, eps_2 = eps_2))
    r <- cheb_roots(3^iota)
    b <- marginal_density(Psi)
    beta <- cheb_bisect(cheb_int(b), (r + 1) / 2, eps_3)
    C <- conditional_density(Psi, b, r)
    V <- t(apply(cheb_int_mat(C), 2,
                 function(c) cheb_bisect(c, (r + 1) / 2, eps_4)))
    D <- ACA(V, 3^iota, eps_5)
    list(a = cheb_trunc(cheb_coef(beta), eps= eps_5),
         Psi = list(A_1 = cheb_trunc_mat(cheb_coef_mat(t(D$R)), eps_6),
                  A_2 = cheb_trunc_mat(cheb_coef_mat(D$C), eps_6),
                  u = D$u))
}
#line 2274 "chebsample.nw"
lr_sample <- function(o, Q, n)
{
    alpha <- sobol(n, 2)
    eta_1 <- cheb_val(Q$a, map_alpha(alpha[,1]))
    eta_2 <- lr_val(Q$Psi, eta_1, map_alpha(alpha[,2]))
    cbind(gamma_1 = map_eta(o, eta_1, 1),
          gamma_2 = map_eta(o, eta_2, 2))
}
