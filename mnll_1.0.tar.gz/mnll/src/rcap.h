#ifndef I_RCAP_H
#define I_RCAP_H

void blas_mv(double *A, double *x, int m, int n,
             double alpha, double beta, double *y);
void make_unit_vector(double *x, int n);

struct sampling_object {
    int m;
    double r2;
    double lambda;
    double phi;
    double rho;
    double tau;
    int lwork;
    double *work;
    double Fa;
};
typedef struct sampling_object *obj;

obj setup(int m, double r);
double *cB(obj o, double *a, double *aB);
void rcap(obj o, double *A, int ell, int n, double *Y);
void cleanup(obj o);
#endif  /* define I_RCAP_H */
