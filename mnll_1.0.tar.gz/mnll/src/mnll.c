#include "rcap.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <R.h>
#include <Rmath.h>
#include <R_ext/Random.h>
#include <R_ext/BLAS.h>
#include <R_ext/Utils.h>

void R_CheckUserInterrupt(void);

// Calculate mean and the standard deviation of a vector $x$ of length $n$;
// uses two passes for better accuracy; see numerical recipes, page 725.
static void mean_and_sd(double *x, int n, double *mean, double *sd)
{
    double a = 0.0;
    double v = 0.0;
    double eps = 0.0;
    double c;
    // first pass
    for (int i = 0; i < n; i++)
        a += x[i];
    a /= n;
    // second pass
    for (int i = 0; i < n; i++) {
        c = x[i] - a;
        eps += c;
        v += c * c;
    }
    *sd = sqrt((v - eps * eps / n) / (n - 1)) ;
    // return the results
    *mean = a + eps / n;

}

// Calculate the dot product $x^{\top} y$,
// where $x$ and $y$ are vectors of length $n$.
static double blas_dot(int n, double *x, double *y)
{
    int int1 = 1;
    return F77_NAME(ddot)(&n, x, &int1, y, &int1);
}


// Calculate $A^{\top} B$, where $\rows(A) = \rows(B)$.
// $A$ and $B$ are stored in column-major ordering.
// Store the result as matrix $C$ (vector of length $\cols(A)\cols(B)$).
static void blas_mm(double *A, double *B, double *C,
               int rows, int cols_a, int cols_b)
{
    char transa = 'T';
    char transb = 'N';
    double alpha = 1.0;
    double beta = 0.0;
    F77_NAME(dgemm)(&transa, &transb, &cols_a, &cols_b, &rows,
                    &alpha, A, &rows, B, &rows, &beta, C, &cols_a);
}

// Calculate the volume of the spherical cap described
// by the object ``o'', divided by the volume of the sphere.
static double volume_ratio(obj o)
{
    return 0.5 * pbeta(o->r2, 0.5, 0.5 * (o->m - 1), 0, 0);
}

// Calculate the volume of the $d - 1$ dimensional unit sphere.
static double volume_sphere(obj o)
{
    return 2 * pow(M_PI, 0.5 * o->m) / gammafn(0.5 * o->m);
}

// Calculate the volume of the spherical cap described
static double volume_cap(obj o)
{
    return volume_sphere(o) * volume_ratio(o);
}

/* Density of $\tilde{y} \in \mathbb{R}^d$ under the alternative hypothesis.

Note first that $\tilde{y} = (B y / \sigma) / \norm{B y / \sigma}$
where $(B y / \sigma) \sim \mathcal{N}(\delta \tilde{x} , I_d)$
with \delta = \beta \norm{B x} / \sigma$.
Equation 3.9 by Pukkila and Rao (1988) then gives the
density of $\tilde{y}$, with $Q_1 = \delta^2$,
with $Q_2 = \delta \tilde{x}^{\top} \tilde{y}$,
with $Q_3 = 1$, and with $\Sigma^{-1/2} = I_d$.

Ipa is an internal helper function.
*/
static double Ipa(int p, double a)
{
    double x = sqrt(2 * M_PI) * pnorm(a, 0, 1, 1, 0);
    double y = exp(- 0.5 * a * a) + a * x;
    for (int q = 2; q < p; q++) {
        double z = (q - 1) * x + a * y;
        x = y;
        y = z;
    }
    return y;
}
// Calculating T1 is surprisingly expensive, so we precalculate its value.
static double ag_density(double *tx, double *ty, double delta, int d, double T1)
{
    double r = blas_dot(d, tx, ty);
    // double T1 = pow(2.0 * M_PI, -0.5 * d);
    double T2 = Ipa(d, delta * r);
    double T3 = exp(0.5 * delta * delta * (r * r - 1));
    return T1 * T2 * T3;
}

// W a matrix of dimension $d \times n$ of $n$ points on $\mathbb{M}$.
//
// In each of the $\variable{block_size} iteration of a block, $\ell$
// points are sampled from the spherical cap of radius $r$ around each
// point in $W$. Then the mean and the standard deviation is
// calculated from each of the iterations in a block
//
// This procedure is repeated for further blocks until either
// the estimated standard error of is below the prespecified
// threshold $\variable{se_threshold}$, or the prespecified
// maximal number $\variable{max_block}$ of blocks is reached.
//
// The estimate of the standard error in the $b$-th iteration is
// s_b / \sqrt{b \variable{block_size}}$
// where $s_b$ is the mean of the estimated standard deviations
// in the first $b$ blocks.
double mnll_pvalue(double r, double *W, int d, int n, int ell,
                   int block_size, int max_blocks, double se_threshold,
                   int verbose)
{
    double *p_block = malloc(sizeof(double) * block_size); // array of pvalues
    double p_sum = 0; // sum of the pvalues in the different blocks
    double p_mean;
    double sd_sum = 0;
    double sd_mean;
    double se;

    obj o = setup(d, r * r);
    double *V = malloc(sizeof(double) * d * n * ell);

    double *Z = malloc(sizeof(double) * n * ell * n);
    double vol_ratio = volume_ratio(o);

    for (int block = 1; block  <= max_blocks; block++) {
        for (double *p = p_block; p < p_block + block_size; p++) {
            rcap(o, W, ell, n, V);
            blas_mm(W, V, Z, d, n, n  * ell);
            /* Calculate $s = \sum_{i=1, \dots, n\ell} 1 / k_i$,
               with $k_i$ the number of elements in the $i$-th column
               of $Z$ exceeding $r$. */
            double s = 0.0;
            // for loop over columns of $Z$ and $V$
            for (double *z = Z; z < Z + n * ell * n;) {
                int k = 0;
                // loop over elements in the current column of $Z$
                for (int j = 0; j < n; j++) {
                    if (*z++ >= r)
                        ++k;
                }
                s += 1.0 / k;
            }
            /* Calculate the pvalue now */
            *p = s * vol_ratio / ell;
        }
        double mean, sd;
        mean_and_sd(p_block, block_size, &mean, &sd);
        p_sum += mean;
        p_mean = p_sum / block;
        sd_sum += sd;
        sd_mean = sd_sum / block;
        se = sd_mean / sqrt(block * block_size);

        if (verbose)
            Rprintf("SE = %f in block %d\n", se, block);

        if (se < se_threshold)
            break;
        }

    free(V);
    free(Z);
    free(p_block);
    cleanup(o);
    return p_mean;
}

// W a matrix of dimension $d \times n$ of $n$ points on $\mathbb{M}$.
//
// In each of the $\variable{block_size} iteration of a block, $\ell$
// points are sampled from the spherical cap of radius $r$ around each
// point in $W$. These sampled points are weighted according to the
// angular Gaussian density with parameters $\tilde{x}$ and $\delta$,
// so that $(B y) / \sigma \sim \mathcal{N}(\delta \tilde{x}, I_d).
// Then the mean and the standard deviation is
// calculated from each of the iterations in a block.
//
// This procedure is repeated for further blocks until either
// the estimated standard error of is below the prespecified
// threshold $\variable{se_threshold}$, or the prespecified
// maximal number $\variable{max_block}$ of blocks is reached.
//
// The estimate of the standard error in the $b$-th iteration is
// s_b / \sqrt{b \variable{block_size}}$
// where $s_b$ is the mean of the estimated standard deviations
// in the first $b$ blocks.
double mnll_power(double r, double *W, double *tx, double delta,
                  int d, int n, int ell,
                  int block_size, int max_blocks, double se_threshold,
                  int verbose)
{
    double *p_block = malloc(sizeof(double) * block_size); // array of powers
    double p_sum = 0; // sum of the estimated powers in the different blocks
    double p_mean;
    double sd_sum = 0;
    double sd_mean;
    double se;

    obj o = setup(d, r * r);
    double *V = malloc(sizeof(double) * d * n * ell);

    double *Z = malloc(sizeof(double) * n * ell * n);
    double vol_cap = volume_cap(o);
    double T1 = pow(2.0 * M_PI, -0.5 * d);

    for (int block = 1; block  <= max_blocks; block++) {
        for (double *p = p_block; p < p_block + block_size; p++) {
            rcap(o, W, ell, n, V);
            blas_mm(W, V, Z, d, n, n  * ell);
            /* Calculate $s = \sum_{i=1, \dots, n\ell} f_i / k_i$,
               with $k_i$ the number of elements in the $i$-th column
               of $Z$ exceeding $r$, and with $f_i$ the angular
               gaussian density (with parameters $\tilde{x}$
               and $\delta$) of the $i$-th column of the matrix $v$.
            */
            double s = 0.0;
            double *v_last = V + d * n * ell - 1; // pointer to last elm in V
            // loop over columns of $Z$ and $V$
            for (double *z = Z, *v = V; v <= v_last; v += d) {
//            for (double *z = Z, *v = V; z < Z + n * ell * n; v += d) {
                double f = ag_density(tx, v, delta, d, T1);
                int k = 0;
                // loop over elements in a column of $Z$
                for (int j = 0; j < n; j++) {
                    if (*z++ >= r)
                        ++k;
                }
                s += f / k;
            }
            /* Calculate the power now */
            *p = s * vol_cap / ell;
        }
        double mean, sd;
        mean_and_sd(p_block, block_size, &mean, &sd);
        p_sum += mean;
        p_mean = p_sum / block;
        sd_sum += sd;
        sd_mean = sd_sum / block;
        se = sd_mean / sqrt(block * block_size);

        if (verbose)
            Rprintf("SE = %f in block %d\n", se, block);

        if (se < se_threshold)
            break;
        }

    free(V);
    free(Z);
    free(p_block);
    cleanup(o);
    return p_mean;
}

// The R Bindings
void mnll_pvalue_rbinding(double *res, double *r, double *W, int *d, int *n,
                          int *ell, int *block_size, int *max_blocks,
                          double *se_threshold, int *verbose)
{
    GetRNGstate();
    *res = mnll_pvalue(*r, W, *d, *n, *ell,
                      *block_size, *max_blocks, *se_threshold, *verbose);
    PutRNGstate();
}
void mnll_power_rbinding(double *res, double *r, double *W,
                         double *tx, double *delta,
                         int *d, int *n,
                         int *ell, int *block_size, int *max_blocks,
                         double *se_threshold, int *verbose)
{
    GetRNGstate();
    *res = mnll_power(*r, W, tx, *delta, *d, *n, *ell,
                      *block_size, *max_blocks, *se_threshold, *verbose);
    PutRNGstate();
}
