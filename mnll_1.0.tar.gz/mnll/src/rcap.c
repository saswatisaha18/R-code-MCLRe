#line 289 "rcap.nw"
#include <stdlib.h>
#line 432 "rcap.nw"
#include <string.h>
#line 487 "rcap.nw"
#include <R.h>
#line 625 "rcap.nw"
#include <R_ext/BLAS.h>
#include <R_ext/Lapack.h>
#line 641 "rcap.nw"
double blas_nrm2(double *x, int n)
{
    int int1 = 1;
    return F77_NAME(dnrm2)(&n, x, &int1);
}
#line 652 "rcap.nw"
void blas_scal(double alpha, double *x, int n)
{
    int int1 = 1;
    F77_NAME(dscal)(&n, &alpha, x, &int1);
}
#line 663 "rcap.nw"
void make_unit_vector(double *x, int n)
{
    double norm = blas_nrm2(x, n);
    blas_scal(1.0 / norm, x, n);
}
#line 684 "rcap.nw"
void blas_mv(double *A, double *x, int m, int n,
             double alpha, double beta, double *y)
{
    char trans = 'N';
    int int1 = 1;

    F77_NAME(dgemv)(&trans, &m, &n, &alpha, A,
                    &m, x, &int1, &beta, y, &int1);
}
#line 758 "rcap.nw"
void lapack_basis(double *a, int m, double *U,
                  double *work, int lwork)
{
    char jobu = 'A';
    char jobvt = 'N';
    int int1 = 1;
    int info;
    double s;
    double *work1 = work;
    double *work2 = work + m;
    memcpy(work1, a, m * sizeof(double));

    F77_NAME(dgesvd)(&jobu, &jobvt, &m, &int1, work1, &m,
                     &s, U, &m, 0, &m, work2, &lwork, &info);
}
#line 791 "rcap.nw"
int lapack_basis_lwork(int m)
{
    int lwork = -1;
    double work[2 * m];
    lapack_basis(work, m, work, work, lwork);
    return (int) work[m];
}
#line 254 "rcap.nw"
struct bookkeeping_object {
    int m;
    double r2;
    
#line 356 "rcap.nw"
double Hr2;
#line 258 "rcap.nw"
    
#line 780 "rcap.nw"
int lwork;
double *work;
#line 259 "rcap.nw"
};
typedef struct bookkeeping_object *obj;
#line 731 "rcap.nw"
double *cB(obj o, double *a, double *U)
{
    lapack_basis(a, o->m, U, o->work, o->lwork);
    return U + o->m;
}
#line 268 "rcap.nw"
obj setup(int m, double r2)
{
    obj o = malloc(sizeof(struct bookkeeping_object));
    o->m = m;
    o->r2 = r2;
    
#line 359 "rcap.nw"
o->Hr2 = 1 - pow(1 - o->r2, 0.5 * (o->m - 1.0));
#line 274 "rcap.nw"
    
#line 801 "rcap.nw"
o->lwork = lapack_basis_lwork(m);
o->work = malloc((o->lwork + m) * sizeof(double));
#line 275 "rcap.nw"
    return o;
}
#line 282 "rcap.nw"
void cleanup(obj o)
{
    
#line 805 "rcap.nw"
free(o->work);
#line 285 "rcap.nw"
    free(o);
}
#line 365 "rcap.nw"
double rR2(obj o)
{
    while(1) {
        double u = unif_rand();
        double w = unif_rand();
        double p = o->Hr2 + w * (1 - o->Hr2);
        double v = 1 - pow(1 - p, 2.0 / (o->m - 1));
        if(u * u * v <= o->r2)
            return v;
    }
}
#line 394 "rcap.nw"
void rS(obj o, double *x)
{
    int dim = o->m - 1;

    for (int i = 0; i < dim; i++)
        x[i] = norm_rand();
    make_unit_vector(x, dim);
}
#line 417 "rcap.nw"
void rcap1(obj o, double *a, double *B, double *y)
{
    double R2 = rR2(o);
    double S[o->m - 1];
    rS(o, S);
    memcpy(y, a, o->m * sizeof(double));
    blas_mv(B, S, o->m, o->m - 1, sqrt(1 - R2), sqrt(R2), y);
}
#line 449 "rcap.nw"
void rcap(obj o, double *A, int ell, int n, double *Y)
{
    int m = o->m;
    double U[m * m];
    double *y = Y;
    for (double *a = A; a < A + m * n; a += m) {
        double *B = cB(o, a, U);
        for (double *z = y + ell * m; y  < z; y += m)
            rcap1(o, a, B, y);
    }
}
#line 473 "rcap.nw"
void rcap_bind(double *A, int *ell, int *m,
               int *n, double *r2, double *Y)
{
    GetRNGstate();
    obj o = setup(*m, *r2);
    rcap(o, A, *ell, *n, Y);
    cleanup(o);
    PutRNGstate();
}
