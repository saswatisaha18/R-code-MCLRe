# This file is sourced by the remaining R files.
library(chebsample)

# Calculate the crossproduct between two vector $x$ and $y$,
# or $\norm{x}^2$ if $y$ is not specified.
cp <- function(x, y = NULL)
    drop(crossprod(x, y))

# Calculate the length of a vector $x$.
euclid <- function(x)
    sqrt(cp(x))

# Scale a vector $x$ to unit length.
scl <- function(x)
    x / euclid(x)

# Sample a point uniformly from $\mathbb{S}^d$.
rS <- function(d)
    scl(rnorm(d))

# Calculate a matrix $B$ of dimension $(n - 1) \times n$
# so that the rows of $B$ form an orthonormal basis for
# the orthonormal complement of the one-vector in $\mathbb{R}^{n}.
getB <- function(n)
    t(svd(rep(1, n), n , n)$u[,-1])

# Given a vector $v$ and a basis matrix $B$ of suitable dimension,
# calculate $B (v - \bar{\bar{v}}) / \norm{B (v - \bar{\bar{v}}}$,
# so that [[stat(B, x)]] and [[stat(B, y)]] calculate
# (in the notation of the manuscript) $\tilde{x}$ and $\tilde{y}$.
stat <- function(B, v)
    scl(B %*% v)

# Returns $\abs{\mathbb{C}_{0 r}^d} / \abs{\mathbb{S}^d}$
# the volume of the spherical cap of projective distance $r \in [0, 1]$
# divided by the volume of the $d$ dimensional unit sphere.
# See Equation (1) in the paper ``Concise Formulas for the Area and
# Volume of a Hyperspherical Cap'' by Li (2011).
volume_ratio <- function(r, d)
    (1/2) * (1 - pbeta(r^2, 1/2, (d - 1) / 2))

# Returns $\abs{\mathbb{S}^d}$.
volume_sphere <- function(d)
    2 * pi^(d / 2) / gamma(d / 2)

# Returns $\abs{\mathbb{C}_{1 r}^d}$,
volume_cap <- function(r, d)
    volume_sphere(d) * volume_ratio(r, d)

# Given a critical value for a t-test with $\variable{df} degrees of freedom,
# calculate the corresponding value for the $R$ statistic;
# see Appendix A.5 in the file ``reduction_to_sample_means.pdf''.
crit.t_to_r <- function(crit.t, df)
    crit.t / sqrt(crit.t^2 + df)

# Given the level and the degrees of freedom in a linear model,
# return a critical value for the $R$ statistic.
linear_crit <- function(alpha, df)
    crit.t_to_r(qt(alpha, df, lower.tail = FALSE), df)

# Exact critical error when $\mathbb{M}$ is a ``sufficently smooth'' curve;
# see Johansen and Johnstone, Eq (2.3), page 656, for the details.
# Arguments are the critical value $r$, the dimension $d$, and the
# length of the curve $\mathbb{M}$.
curve_error <- function(r, d, Length)
    Length * (1 - r^2)^((d - 2) / 2) / (2 * pi) + volume_ratio(r, d)

# Find, by root search, the critical value for given a level $\alpha$.
curve_crit <- function(alpha, d, Length)
    uniroot(function(r) curve_error(r, d, Length) - alpha, c(0, 1))$root

# Let $H_0 : y \sim \mathcal{N}(\alpha_0 + \beta_0 x, \sigma^2 I_n)$
# denote the true hypothesis and
# $H_1 : y \sim \mathcal{N}(\alpha_1 + \beta_1 z, \sigma^2 I_n)$
# an incorrect hypothesis, where
# $\norm{x} = \norm{z} = 1$ and $x^{\top}1_n = z^{\top}1_n = 0$.
#
# The t-Test for $\beta_1 = 0$ has the form
# $T = \hat{\beta}_1 / \sqrt{V / (n - 2)}$,
# with
# \[\hat{\alpha}_1 = \bar{y} - \hat{\beta}_1, \qquad
# \hat{\beta}_1 = z^{\top}y, \qquad
# V = \norm{y - \hat{\alpha}_1 - \hat{\beta}_1 z}^2.
# \]
#
# Now $\hat{\beta}_1 \sim \mathcal{N}(\beta_0 x^{\top}z, \sigma^2)$
# and, by an arguments due to Severini (1998, p. 151,
# ``Some properties of inference in misspecified linear models''),
# $\hat{\beta}_1$ is independent of $V \sim \sigma ^2 \chi_{n - 2}^2(\lambda)$
# with noncentrality parameter
# $\lambda = \norm{\beta_0 (x - (x^{\top} z) z)}^2 = \beta_0^2 (1 -
# (x^{\top} z)^2)$.
#
#It follows that $T$ has a doubly-noncentral t-distribution.
lin_power <- function(t.lin, df, delta, ip)
{
   if (ip > 0.9999)
        pt(t.lin, df, delta, lower.tail = FALSE)
    else
        1 - pdnt(t.lin, df, delta * ip, delta^2 * (1 - ip^2))
}

# Find, by root search, the value of delta, so that a t-test with of
# with $\variable{df}$ degrees of freedom and level $\alpha$
# has power $\variable{power}.
# The search for $\delta$ is restricted to $[0, \variable{upper_bound}]$.
getDelta <- function(df, alpha, power, upper_bound = 20)
{
    crit.t <- qt(alpha, df, lower.tail = FALSE)
    uniroot(function(delta) pt(crit.t, df, delta, lower.tail = FALSE) - power,
            lower = 0, upper = upper_bound)$root
}

# Code from the book ``Intermediate Probability: A Computational Approach'',
# page 380, to calculate CDF of the doubly noncentral T distribution.
pdnt <- function(tvec, k, mu, theta)
{
    cdf <- numeric()
    for(tloop in 1:length(tvec)) {
        t <- tvec[tloop]
        hi <- inc <- 50
        done <- lo <- partsum <- 0

        while (!done) {
            ivec <- seq(lo, hi)
            lnw <- -theta / 2 + ivec * log(theta / 2) - lgamma(ivec + 1)
            k2i <- k + 2 * ivec
            logcdfpart <- log(pt(t * sqrt(k2i / k), k2i, mu))
            newpartvec <- exp(lnw + logcdfpart)
            newpartsum <- sum(newpartvec)
            partsum <- partsum + newpartsum
            lo <- hi + 1
            hi <- hi + inc
            if(newpartvec[1] >= newpartvec[length(newpartvec)]
               & newpartsum < 1e-12)
                done <- 1
        }
        cdf[tloop] <- as.double(partsum)
    }
    cdf
}

mnll_pvalue <- function(r, W, block_size = 1e3, max_blocks = 1e3,
                        se_threshold = 1e-4, verbose = FALSE)
{
    L <- .C("mnll_pvalue_rbinding",
            res = double(1),
            r = as.numeric(r),
            W = as.numeric(W),
            d = nrow(W),
            n = ncol(W),
            ell = 1L,
            block_size = as.integer(block_size),
            max_blocks = as.integer(max_blocks),
            se_threshold = as.numeric(se_threshold),
            verbose = as.integer(verbose))
    L$res
}

mnll_power <- function(r, W, tx, delta,
                       block_size = 1e3, max_blocks = 1e3,
                       se_threshold = 1e-4, verbose = FALSE)
{
    L <- .C("mnll_power_rbinding",
            res = double(1),
            r = as.numeric(r),
            W = as.numeric(W),
            tx = as.numeric(tx),
            delta = as.numeric(delta),
            d = nrow(W),
            n = ncol(W),
            ell = 1L,
            block_size = as.integer(block_size),
            max_blocks = as.integer(max_blocks),
            se_threshold = as.numeric(se_threshold),
            verbose = as.integer(verbose))
    L$res
}
